
import java.sql.Connection;
import java.sql.Date;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.SpinnerModel;


public class MainFrame extends javax.swing.JDialog {

    
    private static Connection connection;
    private FacultyQuery facultyQuery = new FacultyQuery();
    private RoomQuery roomQuery = new RoomQuery();
    private DateQuery dateQuery = new DateQuery();
    private Dates Dates = new Dates();
    private ReservationsQuery resQuery = new ReservationsQuery();
    private WaitListQuery wlQuery;
             
             
    public MainFrame(java.awt.Frame parent, boolean modal) {
        
        initComponents();
        
        reserveCombo.setModel(new javax.swing.DefaultComboBoxModel(FacultyQuery.getAllFaculty().toArray()));  
        
        cancelCombo.setModel(new javax.swing.DefaultComboBoxModel(FacultyQuery.getAllFaculty().toArray()));
        
        facultyStatCombo.setModel(new javax.swing.DefaultComboBoxModel(FacultyQuery.getAllFaculty().toArray()));
        
        cancelDateCombo.setModel(new javax.swing.DefaultComboBoxModel(dateQuery.getAllDates().toArray()));
        
        reserveDateSpinner.setModel(new javax.swing.DefaultComboBoxModel(dateQuery.getAllDates().toArray()));
        
        dropRoomCombo.setModel(new javax.swing.DefaultComboBoxModel(roomQuery.getRoomNameList().toArray()));
        
        resByDateTxtArea.setText(resQuery.showReservation());
        
        waitlistTxt.setText(resQuery.getWaitList());
        

    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        mainFrameTitleJLabel = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        facultyNameLabel = new javax.swing.JLabel();
        txtaddFaculty = new javax.swing.JTextField();
        addFacultyButton = new javax.swing.JButton();
        lblFacultyAdded = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        resFacultyLabel = new javax.swing.JLabel();
        resDateLabel = new javax.swing.JLabel();
        resSeatsLabel = new javax.swing.JLabel();
        reserveCombo = new javax.swing.JComboBox();
        seatsReqLabel = new javax.swing.JTextField();
        reserveRoomButton = new javax.swing.JButton();
        reserveRoomLabel = new javax.swing.JLabel();
        reserveDateSpinner = new javax.swing.JComboBox();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        resByDateTxtArea = new javax.swing.JTextArea();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        waitlistTxt = new javax.swing.JTextArea();
        jPanel9 = new javax.swing.JPanel();
        facultyStatLabel = new javax.swing.JLabel();
        facultyStatCombo = new javax.swing.JComboBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        findStatTxtArea = new javax.swing.JTextArea();
        findStatButton = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        roomNameLabel = new javax.swing.JLabel();
        setSeatsLabel = new javax.swing.JLabel();
        addRoomButton = new javax.swing.JButton();
        roomNameInput = new javax.swing.JTextField();
        setSeatsInput = new javax.swing.JTextField();
        addRoomLabel = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        dropRoomInput = new javax.swing.JLabel();
        dropRoomButton = new javax.swing.JButton();
        dropRoomLabel = new javax.swing.JLabel();
        dropRoomCombo = new javax.swing.JComboBox();
        jPanel8 = new javax.swing.JPanel();
        addDateButton = new javax.swing.JButton();
        chooseDateLabel = new javax.swing.JLabel();
        chooseDateSpinner = new javax.swing.JSpinner();
        addDateLabel = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        cancelFacLabel = new javax.swing.JLabel();
        cancelCombo = new javax.swing.JComboBox();
        cancelDateLabel = new javax.swing.JLabel();
        cancelResButton = new javax.swing.JButton();
        cancelDateCombo = new javax.swing.JComboBox();
        cancelResLabel = new javax.swing.JLabel();
        cancelWaitCombo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        mainFrameTitleJLabel.setText("Room Scheduler");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(mainFrameTitleJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(264, 264, 264))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(mainFrameTitleJLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                .addContainerGap())
        );

        facultyNameLabel.setText("Faculty Name:");

        txtaddFaculty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtaddFacultyActionPerformed(evt);
            }
        });

        addFacultyButton.setText("Add Faculty");
        addFacultyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addFacultyButtonActionPerformed(evt);
            }
        });

        lblFacultyAdded.setText("    ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblFacultyAdded, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(facultyNameLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtaddFaculty, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(addFacultyButton)))
                .addContainerGap(338, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(facultyNameLabel)
                    .addComponent(txtaddFaculty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addFacultyButton))
                .addGap(40, 40, 40)
                .addComponent(lblFacultyAdded)
                .addContainerGap(363, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Add Faculty", jPanel2);

        resFacultyLabel.setText("Faculty:");

        resDateLabel.setText("Date:");

        resSeatsLabel.setText("Seats Required:");

        reserveCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        reserveCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reserveComboActionPerformed(evt);
            }
        });

        seatsReqLabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatsReqLabelActionPerformed(evt);
            }
        });

        reserveRoomButton.setText("Submit");
        reserveRoomButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reserveRoomButtonActionPerformed(evt);
            }
        });

        reserveDateSpinner.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(resFacultyLabel)
                                    .addComponent(resDateLabel))
                                .addGap(65, 65, 65)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(reserveDateSpinner, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(reserveCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(resSeatsLabel)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(reserveRoomButton)
                                    .addComponent(seatsReqLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(reserveRoomLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 686, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resFacultyLabel)
                    .addComponent(reserveCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resDateLabel)
                    .addComponent(reserveDateSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resSeatsLabel)
                    .addComponent(seatsReqLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addComponent(reserveRoomButton)
                .addGap(43, 43, 43)
                .addComponent(reserveRoomLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                .addGap(27, 27, 27))
        );

        jTabbedPane1.addTab("Reserve a Room", jPanel3);

        resByDateTxtArea.setEditable(false);
        resByDateTxtArea.setColumns(20);
        resByDateTxtArea.setLineWrap(true);
        resByDateTxtArea.setRows(5);
        jScrollPane1.setViewportView(resByDateTxtArea);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(94, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Reservations by Date", jPanel4);

        waitlistTxt.setEditable(false);
        waitlistTxt.setColumns(20);
        waitlistTxt.setRows(5);
        jScrollPane3.setViewportView(waitlistTxt);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 694, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(100, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Waitlist", jPanel5);

        facultyStatLabel.setText("Faculty:");

        facultyStatCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        findStatTxtArea.setEditable(false);
        findStatTxtArea.setColumns(20);
        findStatTxtArea.setRows(5);
        jScrollPane2.setViewportView(findStatTxtArea);

        findStatButton.setText("Find Status");
        findStatButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findStatButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(facultyStatLabel)
                .addGap(18, 18, 18)
                .addComponent(facultyStatCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(findStatButton)
                .addContainerGap(363, Short.MAX_VALUE))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(facultyStatLabel)
                    .addComponent(facultyStatCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(findStatButton))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 392, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Faculty Status", jPanel9);

        roomNameLabel.setText("Room Name:");

        setSeatsLabel.setText("Set Seat Amount:");

        addRoomButton.setText("Add Room");
        addRoomButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addRoomButtonActionPerformed(evt);
            }
        });

        roomNameInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomNameInputActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(279, 279, 279)
                        .addComponent(addRoomButton))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(195, 195, 195)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(roomNameLabel)
                            .addComponent(setSeatsLabel))
                        .addGap(90, 90, 90)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(roomNameInput)
                            .addComponent(setSeatsInput, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(addRoomLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 668, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(roomNameLabel)
                    .addComponent(roomNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(setSeatsLabel)
                    .addComponent(setSeatsInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(68, 68, 68)
                .addComponent(addRoomButton)
                .addGap(35, 35, 35)
                .addComponent(addRoomLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Add Room", jPanel6);

        dropRoomInput.setText("Enter Room Name:");

        dropRoomButton.setText("Drop Room");
        dropRoomButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dropRoomButtonActionPerformed(evt);
            }
        });

        dropRoomLabel.setText("                                                            ");

        dropRoomCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(153, 153, 153)
                .addComponent(dropRoomInput)
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dropRoomButton, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dropRoomCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(315, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(dropRoomLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 678, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dropRoomInput)
                    .addComponent(dropRoomCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addComponent(dropRoomButton)
                .addGap(48, 48, 48)
                .addComponent(dropRoomLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
                .addGap(27, 27, 27))
        );

        jTabbedPane1.addTab("Drop Room", jPanel7);

        addDateButton.setText("Add Date");
        addDateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDateButtonActionPerformed(evt);
            }
        });

        chooseDateLabel.setText("Choose Date:");

        chooseDateSpinner.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(1578954600000L), null, null, java.util.Calendar.DAY_OF_MONTH));

        addDateLabel.setText("                                                          ");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(209, 209, 209)
                        .addComponent(addDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(177, 177, 177)
                        .addComponent(chooseDateLabel)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(chooseDateSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addDateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(231, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addGap(130, 130, 130)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chooseDateLabel)
                    .addComponent(chooseDateSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addComponent(addDateButton)
                .addGap(44, 44, 44)
                .addComponent(addDateLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
                .addGap(120, 120, 120))
        );

        jTabbedPane1.addTab("Add Date", jPanel8);

        cancelFacLabel.setText("Faculty:");

        cancelCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cancelCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelComboActionPerformed(evt);
            }
        });

        cancelDateLabel.setText("Date:");

        cancelResButton.setText("Cancel Reservation");
        cancelResButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelResButtonActionPerformed(evt);
            }
        });

        cancelDateCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(235, 235, 235)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cancelFacLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cancelDateLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cancelDateCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cancelCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cancelResButton)))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cancelWaitCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 675, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cancelResLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 675, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancelFacLabel)
                    .addComponent(cancelCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancelDateLabel)
                    .addComponent(cancelDateCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addComponent(cancelResButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cancelResLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cancelWaitCombo, javax.swing.GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );

        jTabbedPane1.addTab("Cancel Reservation", jPanel10);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void reserveRoomButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reserveRoomButtonActionPerformed
        
        String facultyChosen = reserveCombo.getSelectedItem().toString();
        
        SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd"); 
        
        String spinnerValue = formater.format(reserveDateSpinner.getSelectedItem());
        
        Date day = Date.valueOf(spinnerValue);
        
        Date selectedDate = (Date) reserveDateSpinner.getSelectedItem();
        
        int seatsNeeded = Integer.parseInt(seatsReqLabel.getText());
        
        resQuery.addReservation(facultyChosen, selectedDate, seatsNeeded);
        
        reserveRoomLabel.setText(resQuery.statOfReservation);
        
        refreshResAndWL();
        
        
    }//GEN-LAST:event_reserveRoomButtonActionPerformed

    private void seatsReqLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatsReqLabelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_seatsReqLabelActionPerformed

    private void addFacultyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addFacultyButtonActionPerformed
        
        int result = facultyQuery.addFaculty(txtaddFaculty.getText());
        
        if (result == 1) {
            lblFacultyAdded.setText(txtaddFaculty.getText()  + " has been added to Faculty");
            
            reserveCombo.removeAllItems();
            cancelCombo.removeAllItems();
            facultyStatCombo.removeAllItems();
            
            reserveCombo.setModel(new javax.swing.DefaultComboBoxModel(FacultyQuery.getAllFaculty().toArray()));
            cancelCombo.setModel(new javax.swing.DefaultComboBoxModel(FacultyQuery.getAllFaculty().toArray()));
            facultyStatCombo.setModel(new javax.swing.DefaultComboBoxModel(FacultyQuery.getAllFaculty().toArray()));
        }
        else {
            lblFacultyAdded.setText(txtaddFaculty.getText()  + " cannot be added to Faculty");
        }
    }//GEN-LAST:event_addFacultyButtonActionPerformed

    private void txtaddFacultyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtaddFacultyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtaddFacultyActionPerformed

    private void roomNameInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomNameInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_roomNameInputActionPerformed

    private void reserveComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reserveComboActionPerformed
       
    }//GEN-LAST:event_reserveComboActionPerformed

    private void addRoomButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addRoomButtonActionPerformed
        
        String roomName = roomNameInput.getText();
        
        int setSeats = Integer.parseInt(setSeatsInput.getText());
        
        roomQuery.addRoom(roomName, setSeats);

        addRoomLabel.setText(roomQuery.resWLString);
        
        refreshResAndWL();
        
        dropRoomCombo.removeAllItems();
        
        dropRoomCombo.setModel(new javax.swing.DefaultComboBoxModel(roomQuery.getRoomNameList().toArray()));

    }//GEN-LAST:event_addRoomButtonActionPerformed

    private void dropRoomButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dropRoomButtonActionPerformed
        
        String roomName = dropRoomCombo.getSelectedItem().toString();
        
        roomQuery.dropRoom(roomName);
        
        dropRoomLabel.setText("<html>Room " + roomName + " has been dropped.<html> <br/>" + roomQuery.dropRoomStr);
        
        refreshResAndWL();
        
        dropRoomCombo.removeAllItems();
        
        dropRoomCombo.setModel(new javax.swing.DefaultComboBoxModel(roomQuery.getRoomNameList().toArray()));
    }//GEN-LAST:event_dropRoomButtonActionPerformed

    private void addDateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDateButtonActionPerformed
        
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        
        String spinnerValue = formatter.format(chooseDateSpinner.getValue());
        
        Date day = Date.valueOf(spinnerValue);
        
        dateQuery.addDate(day);
        
        cancelDateCombo.setModel(new javax.swing.DefaultComboBoxModel(dateQuery.getAllDates().toArray()));
        
        reserveDateSpinner.setModel(new javax.swing.DefaultComboBoxModel(dateQuery.getAllDates().toArray()));
        
        addDateLabel.setText(day + " has been added.");
        
        refreshResAndWL();
    }//GEN-LAST:event_addDateButtonActionPerformed

    private void cancelComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelComboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cancelComboActionPerformed

    private void findStatButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findStatButtonActionPerformed
        
        String faculty = facultyStatCombo.getSelectedItem().toString();
        
        resQuery.resByFacultyLayout(faculty);
        
        findStatTxtArea.setText(resQuery.showFaculty);
    }//GEN-LAST:event_findStatButtonActionPerformed

    private void cancelResButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelResButtonActionPerformed
        
        String cancel = cancelCombo.getSelectedItem().toString();
        
        Date selectedDate = (Date) cancelDateCombo.getSelectedItem();
        
        resQuery.checkDelete(cancel, selectedDate);
  
        cancelResLabel.setText(cancel + "<html>'s reservation on " + selectedDate + " has been cancelled.<html><br/>");
            
        cancelWaitCombo.setText(resQuery.changeWLMess);
        
        refreshResAndWL();
        
    }//GEN-LAST:event_cancelResButtonActionPerformed
    
    private void refreshResAndWL() {
        
        resByDateTxtArea.setText(resQuery.showReservation());
        waitlistTxt.setText(resQuery.getWaitList());
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                connection = dbConnection.getConnection();
                MainFrame dialog = new MainFrame(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addDateButton;
    private javax.swing.JLabel addDateLabel;
    private javax.swing.JButton addFacultyButton;
    private javax.swing.JButton addRoomButton;
    private javax.swing.JLabel addRoomLabel;
    private javax.swing.JComboBox cancelCombo;
    private javax.swing.JComboBox cancelDateCombo;
    private javax.swing.JLabel cancelDateLabel;
    private javax.swing.JLabel cancelFacLabel;
    private javax.swing.JButton cancelResButton;
    private javax.swing.JLabel cancelResLabel;
    private javax.swing.JLabel cancelWaitCombo;
    private javax.swing.JLabel chooseDateLabel;
    private javax.swing.JSpinner chooseDateSpinner;
    private javax.swing.JButton dropRoomButton;
    private javax.swing.JComboBox dropRoomCombo;
    private javax.swing.JLabel dropRoomInput;
    private javax.swing.JLabel dropRoomLabel;
    private javax.swing.JLabel facultyNameLabel;
    private javax.swing.JComboBox facultyStatCombo;
    private javax.swing.JLabel facultyStatLabel;
    private javax.swing.JButton findStatButton;
    private javax.swing.JTextArea findStatTxtArea;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblFacultyAdded;
    private javax.swing.JLabel mainFrameTitleJLabel;
    private javax.swing.JTextArea resByDateTxtArea;
    private javax.swing.JLabel resDateLabel;
    private javax.swing.JLabel resFacultyLabel;
    private javax.swing.JLabel resSeatsLabel;
    private javax.swing.JComboBox reserveCombo;
    private javax.swing.JComboBox reserveDateSpinner;
    private javax.swing.JButton reserveRoomButton;
    private javax.swing.JLabel reserveRoomLabel;
    private javax.swing.JTextField roomNameInput;
    private javax.swing.JLabel roomNameLabel;
    private javax.swing.JTextField seatsReqLabel;
    private javax.swing.JTextField setSeatsInput;
    private javax.swing.JLabel setSeatsLabel;
    private javax.swing.JTextField txtaddFaculty;
    private javax.swing.JTextArea waitlistTxt;
    // End of variables declaration//GEN-END:variables
}


