
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;



public class DateQuery {
    
    
    private PreparedStatement addDate;
    private static PreparedStatement selectAllDates; 
    private static Connection connection;
    private List <Faculty> result = new ArrayList < Faculty >();
    
    
    
    public DateQuery() {
        connection = dbConnection.getConnection();
}
    
    
    public int addDate(Date date) {
        
        try {

            addDate = connection.prepareStatement("INSERT INTO DATES (DATE) VALUES(?)");
            addDate.setDate(1, date);
            return addDate.executeUpdate();

        }
        
        catch(SQLException exception) {
            exception.printStackTrace();
        }
        
	return 0;	
    }
    
    
    
    public static ArrayList <Date> getAllDates() {
        
        ResultSet resultSet = null;
        
        ArrayList <Date> result = new ArrayList <Date>();
        
        
        try {
            
            selectAllDates = connection.prepareStatement("SELECT DATE FROM DATES ORDER BY DATE");
            resultSet = selectAllDates.executeQuery();
            
            while (resultSet.next()) {
                
                result.add(resultSet.getDate(1));
            }

        }

        catch(SQLException exception) {
            
            exception.printStackTrace();
        }

        return result;	
    }
    
}
