

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.util.Calendar;
import java.sql.Connection;
import java.sql.SQLException;


public class ReservationsQuery {
    
    private static Connection connection;
    private PreparedStatement getRoomResByDate;
    private PreparedStatement addRes;
    private PreparedStatement getResByDate;
    private RoomQuery roomQuery;
    private PreparedStatement getWLByFaculty;
    private boolean addableRes;
    private PreparedStatement getResByFacultyandDate;
    private ArrayList <String> resRoom;
    public String statOfReservation;
    private PreparedStatement delResByFacultyAndDate;
    private WaitListQuery wlQuery;
    public String changeWLMess;
    private PreparedStatement getRoomByFacultyAndDate;
    public String showFaculty;
    private DateQuery dateQuery;
    
    
    public ReservationsQuery() {
        
        connection = dbConnection.getConnection();
        
        addableRes = true;
        
        roomQuery = new RoomQuery();
        

    }
    
    
    public void addReservation(String faculty, Date date, int seats) {
        
        RoomEntry chooseRoom;
        
        chooseRoom = findCorrectRoom(seats);
        
    if (chooseRoom != null) {
        
        statOfReservation = "";
        
        try { 

            checkReserved(date, chooseRoom.getName());

        }

        catch(Exception sqlException) {
            sqlException.printStackTrace();
        }
    
        
        
        Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
        
        
        if (addableRes) {
            
            statOfReservation = String.format("%s has reserved Room %s on %s.", faculty, chooseRoom.getName(), date);

            try {
                
                addRes = connection.prepareStatement("INSERT INTO RESERVATIONS (FACULTY, ROOM, DATE, SEATS, TIMESTAMP) VALUES(?, ?, ?, ?, ?)");
                addRes.setString(1,faculty);
                addRes.setString(2,chooseRoom.getName());
                addRes.setDate(3, date);                    
                addRes.setInt(4,seats);
                addRes.setTimestamp(5, currentTimestamp);
                addRes.executeUpdate();
            }

            catch(SQLException sqlException) {
                sqlException.printStackTrace();
            }
        }
        
        else {
            
            statOfReservation = String.format("%s" + " has been waitlisted until a room becomes available.", faculty);
            
            wlQuery.addWaitlist(faculty, date, seats, currentTimestamp);
            
            addableRes = true;
        }
    }
        
    else {
        
        Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
        
        wlQuery.addWaitlist(faculty, date, seats, currentTimestamp);
            
        addableRes = true;
        
        statOfReservation = String.format("%s" + " has been waitlisted until a room with the required seats is available.", faculty);
    }            
    
    }
    
    
    
    public ArrayList <Reservations> getReservationByDate(Date date) {
        
        ArrayList <Reservations> results = null;
        
        ResultSet resultSet = null;
        
        try {
            
            getResByDate = connection.prepareStatement("SELECT * FROM RESERVATIONS WHERE DATE = ?");
            getResByDate.setDate(1,date);
            resultSet = getResByDate.executeQuery();
            
            results = new ArrayList <Reservations>();
            
            while (resultSet.next()) {
                results.add(new Reservations(resultSet.getString("FACULTY"),
                    resultSet.getString("ROOM"), resultSet.getDate("DATE"), resultSet.getInt("SEATS"),
                    resultSet.getTimestamp("TIMESTAMP")));
            }
        
        }
        
        catch(SQLException sqlException) {
            sqlException.printStackTrace();
        } 
        
        return results;
    
    }
    
    public String getWaitList() {
        
        wlQuery = new WaitListQuery();
        
        return wlQuery.showWaitList();
    
    }
    
    
    public ArrayList <String> getRoomsReservedByDate(Date date) {
        
        ArrayList <String> results = null;
        
        ResultSet resultSet = null;
        
        try {
            
            getRoomResByDate = connection.prepareStatement("SELECT ROOM FROM RESERVATIONS WHERE DATE = ?");
            getRoomResByDate.setDate(1,date);
            resultSet = getRoomResByDate.executeQuery();
            
            results = new ArrayList <String>();
            
            while(resultSet.next()) {
                results.add(resultSet.getString(1));
            }
        }
        
        catch(SQLException sqlException) {
            sqlException.printStackTrace();
        } 
        
        return results;
    
    }
    
    
    public String deleteReservation(String name, Date date) {
        
        
        ArrayList <String> deletedRooms = null;
        
        ResultSet resultSet = null;
           
        try {

            getRoomByFacultyAndDate = connection.prepareStatement("SELECT * from RESERVATIONS WHERE FACULTY = ? AND DATE = ?");
            getRoomByFacultyAndDate.setString(1, name);
            getRoomByFacultyAndDate.setDate(2, date);
            resultSet = getRoomByFacultyAndDate.executeQuery();
            
            deletedRooms = new ArrayList<String>();
            
            while (resultSet.next()) {
                deletedRooms.add(resultSet.getString("ROOM"));
            }
            
            delResByFacultyAndDate = connection.prepareStatement("DELETE FROM RESERVATIONS WHERE FACULTY = ? AND DATE = ?");
            delResByFacultyAndDate.setString(1,name);
            delResByFacultyAndDate.setDate(2,date);
            delResByFacultyAndDate.executeUpdate();
            
            changeWLMess = "";
            
            if (deletedRooms.isEmpty()) {
                
                return "none";
            }      
            
            int seatAmount = 0;
            
            for (int i = 0; i < roomQuery.getAllRooms().size(); i++) {
                
                if (deletedRooms.get(0).equals(roomQuery.getAllRooms().get(i).getName())) {
                    
                    seatAmount = roomQuery.getAllRooms().get(i).getSeats();
                    
                    break;
                }
                
            }
            
            
            for (int j = 0; j < wlQuery.getWLByTimestamp(date).size(); j++) {
                
                if (wlQuery.getWLByTimestamp(date).get(j).getSeats() <= seatAmount) {
                    
                    
                    String nameOfFaculty = wlQuery.getWLByTimestamp(date).get(j).getFaculty();
                    
                    Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
                    
                    addRes = connection.prepareStatement("INSERT INTO RESERVATIONS (FACULTY, ROOM, DATE, SEATS, TIMESTAMP) VALUES(?, ?, ?, ?, ?)");
                    addRes.setString(1, wlQuery.getWLByTimestamp(date).get(j).getFaculty());
                    addRes.setString(2, deletedRooms.get(0));
                    addRes.setDate(3, date);                    
                    addRes.setInt(4, wlQuery.getWLByTimestamp(date).get(j).getSeats());
                    addRes.setTimestamp(5, currentTimestamp);
                    addRes.executeUpdate();
                    
                    changeWLMess = String.format("<html>%s has been moved from the waiting list and reserved Room %s.<html> <br/>",
                            wlQuery.getWLByTimestamp(date).get(j).getFaculty(),deletedRooms.get(0));
                    
                    return nameOfFaculty;
                }
            }
        }
        
        catch(SQLException sqlException) {
           sqlException.printStackTrace();
        }
        
        return null;
    }
    
    

    public RoomEntry findCorrectRoom(int seats) {
        
        int start = -1;
        
        try {
        
            for (int i = 0; i < roomQuery.getAllRooms().size(); i++) {   
                
                if (roomQuery.getAllRooms().get(i).getSeats() >= seats) {
                    
                    start = i;
                }
            }

            return roomQuery.getAllRooms().get(start);
        
        }
            
        catch(Exception e) {              
            return null;
        }
    }
    

    
    
    public void checkReserved(Date date, String room) throws SQLException {

        resRoom = new ArrayList <String>();
                
        resRoom = getRoomsReservedByDate(date);
        
        if (resRoom.isEmpty() || !resRoom.contains(room)) {
            addableRes = true;
        }
        else {
            addableRes = false;
        }

    }

    
    public void checkDelete(String name, Date date ) {
        
        String facultyRes = deleteReservation(name, date);
        
        String changeWLMess = "";

        
        if ("none".equals(facultyRes)) {
            
            changeWLMess = String.format("%s has been removed from the waitlist.", name);
            
            wlQuery.deletWaitlist(name, date);
            
            return;           
        }
        
        wlQuery.deletWaitlist(facultyRes, date);
    }
    
    
    public void resByFacultyLayout(String faculty) {
        
        showFaculty = "";
        
        ArrayList <Reservations> inputRes = null;
        
        ResultSet resultSet= null;
        
        ArrayList <WaitList> inputWL = null;
        
        ResultSet result = null;
        
        try {
            
            getResByFacultyandDate = connection.prepareStatement("SELECT * FROM RESERVATIONS WHERE FACULTY = ?");
            getResByFacultyandDate.setString(1,faculty);
            resultSet = getResByFacultyandDate.executeQuery();
            
            inputRes = new ArrayList <Reservations>();

            while (resultSet.next()) {
                inputRes.add(new Reservations(resultSet.getString("FACULTY"), resultSet.getString("ROOM"),
                resultSet.getDate("DATE"), resultSet.getInt("SEATS"), resultSet.getTimestamp("TIMESTAMP")));
            }
            
            getWLByFaculty = connection.prepareStatement("SELECT * FROM WAILTLIST WHERE FACULTY = ?");
            getWLByFaculty.setString(1,faculty);
            result = getWLByFaculty.executeQuery();
            
            inputWL = new ArrayList <WaitList>();
            
            while (result.next()) {
                inputWL.add(new WaitList(result.getString("FACULTY"), result.getDate("DATE"),
                result.getInt("SEATS"), result.getTimestamp("TIMESTAMP")));
            }
        
            
            showFaculty = faculty + "\n";
            
            for (Reservations results:inputRes) {
                showFaculty += String.format("has reserved room %s on %s\n", results.getRoom(),
                results.getDate().toString());
            }
            
            for (WaitList w_result:inputWL) {
                showFaculty += String.format("is waitlisted on %s\n", w_result.getDate().toString());
            }
            
        }
        
        catch(SQLException sqlException) {              
            sqlException.printStackTrace();    
        }
    }
    
    public String showReservation() {
       

        ArrayList <Reservations> reservation = new ArrayList <Reservations>();

        String prompt = "";

        for (Date day:DateQuery.getAllDates()) {

            prompt += "\n\n" + day + "\n";

            reservation = getReservationByDate(day);

                for (int i = 0; i < reservation.size(); i++) {

                    String faculty = reservation.get(i).getFaculty();

                    String room = reservation.get(i).getRoom();

                    prompt += faculty + " reserved " + room + "\n";
                }
        }
        return prompt;
    }
    
}
