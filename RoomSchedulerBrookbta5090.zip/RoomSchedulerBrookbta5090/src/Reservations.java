

import java.sql.PreparedStatement;
import java.sql.Date;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.Timestamp;


public class Reservations {
    
    private static Connection connection;
    private int seats;
    private String room;
    private Timestamp timestamp;
    private String faculty;
    private Date date;
    
    
    
    public Reservations(String faculty, String room, Date date, int seats, Timestamp timestamp) {
        
        this.room = room;
        this.date = date;
        this.faculty = faculty;
        this.timestamp = timestamp;
        this.seats = seats;   
    }
   
    
    
    public void setRoom(String room) {
        this.room = room; 
    }
    
    public String getRoom() {
        return room;
    }
    
    public void setSeats(int seats) {
        this.seats = seats;
    }
    
    public int getSeats() {
        return seats;
    }
    
    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }
    
    public String getFaculty() {
        return faculty;
    }
    
    
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
    
    public Timestamp getTimestamp() {
        return timestamp; 
    }
    
    public void setDate(Date date) {
        this.date = date;
    }
    
    public Date getDate() {
        return date;
    }

    @Override
    public String toString() {
        return this.getDate() + " " + this.getRoom() + " " ;
    }
    
    
    
}
