

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class FacultyQuery {
    

    private PreparedStatement insertFaculty;
    private PreparedStatement deleteFaculty;
    private static PreparedStatement selectAllFaculty;
    private static Connection connection;

    
    
    public FacultyQuery() {
        connection = dbConnection.getConnection();
        
    }
    
    
    public int addFaculty(String faculty) {
        
        try {
				
        insertFaculty = connection.prepareStatement("INSERT INTO FACULTY" + "(NAME)" + "VALUES(?)");
        insertFaculty.setString(1,faculty);
        return insertFaculty.executeUpdate();

        }
        
        catch(SQLException exception) {
            exception.printStackTrace();
        }
        
	return 0;	
    }
    
            
                       
    public static ArrayList <String> getAllFaculty() {
        
        ResultSet resultSet = null;
        
        ArrayList <String> result = new ArrayList < String >();
        
        try {
				
        selectAllFaculty = connection.prepareStatement("SELECT * FROM FACULTY");
        resultSet = selectAllFaculty.executeQuery();
        
        while (resultSet.next()) {
            
            result.add(resultSet.getString(1));
        }


        }
        
        catch(SQLException exception) {
            exception.printStackTrace();
        }
        
	return result;	
    }
    
}
