


public class RoomEntry {
        
    private String name;
    private int seats;

    public RoomEntry(String name, int seats) {
        this.name = name;
        this.seats = seats;
    }
    
    public RoomEntry() {

    }
    
    public RoomEntry(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    
    public void setSeats(int seats) {
        this.seats = seats;
    }

    public int getSeats() {
        return seats;
    }

    @Override
    public String toString() {
        return this.getName() + " " + this.getSeats();
    }
    
    
    
    
}
