


import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.Date;
import java.util.ArrayList;
import java.sql.ResultSet;
import java.util.Calendar;
import java.sql.PreparedStatement;


public class WaitListQuery {
    
    private PreparedStatement addWaitlist;
    private PreparedStatement deleteByFacultyAndDate;
    private PreparedStatement selectByDate;
    private static Connection connection;
    private PreparedStatement selectByTimestamp;
    private DateQuery dateQuery;
    
    
    public WaitListQuery() {
        
        connection = dbConnection.getConnection();
            
   
    }
    

    public void addWaitlist(String faculty, Date date,  int seats, Timestamp timestamp) {
        
        Timestamp presentStamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
        
        try {
            
            addWaitlist = connection.prepareStatement("INSERT INTO WAILTLIST (FACULTY , DATE, SEATS, TIMESTAMP) VALUES(?, ?, ?, ?)");
            addWaitlist.setString(1,faculty);
            addWaitlist.setDate(2, date);                    
            addWaitlist.setInt(3,seats);
            addWaitlist.setTimestamp(4, presentStamp);
            addWaitlist.executeUpdate();
            
        }
        
        catch(SQLException sqlException) {
            sqlException.printStackTrace();
        }      
    }
    
    
    public void deletWaitlist(String faculty, Date date) {
        
        try {
            
            deleteByFacultyAndDate = connection.prepareStatement("DELETE FROM WAILTLIST WHERE FACULTY = ? AND DATE = ?");
            deleteByFacultyAndDate.setString(1,faculty);
            deleteByFacultyAndDate.setDate(2,date);
            deleteByFacultyAndDate.executeUpdate();
        }
        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }      
    }
    
    
    public  ArrayList <WaitList> getWLByDate(Date date) {
        
        ArrayList <WaitList> result = null;
        
        ResultSet resultSet = null;
        
        try {
            
            selectByDate = connection.prepareStatement("SELECT * FROM WAILTLIST WHERE DATE = ?");
            selectByDate.setDate(1,date);
            
            resultSet= selectByDate.executeQuery();
            result = new ArrayList <WaitList>();
            
            while (resultSet.next()) {
                result.add(new WaitList(resultSet.getString("FACULTY"), resultSet.getDate("DATE"), 
                resultSet.getInt("SEATS"), resultSet.getTimestamp("TIMESTAMP")));}
        }
        
        catch(SQLException sqlException) {
            sqlException.printStackTrace();
        }
        
        return result;
    
    }
    
    
    public String showWaitList() {
        
        
        ArrayList <WaitList> waitlistInput = new ArrayList <WaitList>();
        
        String waitlistPrompt = "";
        
        for (Date day : DateQuery.getAllDates()) {
            
            waitlistPrompt += "\n\n" + day + "\n";
            
            waitlistInput = getWLByDate((Date) day);
            
            for (int i = 0; i < waitlistInput.size(); i++) {
                
                String faculty = waitlistInput.get(i).getFaculty();
                
                Date date = waitlistInput.get(i).getDate();
                
                int seats = waitlistInput.get(i).getSeats();
                
                waitlistPrompt += faculty + " waiting for " + seats +  " seats on " + date + "\n";
            }
        }
        return waitlistPrompt;    
    }
    
    
    
    public ArrayList <WaitList> getWLByTimestamp(Date date) {
        
        ArrayList <WaitList> result = null;
        
        ResultSet resultSet = null;
        
        try {
            
            selectByTimestamp = connection.prepareStatement("SELECT * FROM WAILTLIST WHERE DATE = ? ORDER BY TIMESTAMP");
            selectByTimestamp.setDate(1,date);
            
            resultSet = selectByTimestamp.executeQuery();
            
            result = new ArrayList <WaitList>();
            
            while (resultSet.next()) {
                
                result.add(new WaitList(resultSet.getString("FACULTY"), resultSet.getDate("DATE"), 
                resultSet.getInt("SEATS"),resultSet.getTimestamp("TIMESTAMP")));}
        }
        
        catch(SQLException sqlException) {
            sqlException.printStackTrace();
     }      
        
        return result;
    }
    
    
  
    
}
