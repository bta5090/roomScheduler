

import java.util.Date;

public class Dates {
    
    private Date date;


    public Dates() {

    }
    

    public Dates(Date date) {
        this.date = date;
    }
    
        
    public void setDate (Date date) {
        this.date = date;
    }
    
    
    public Date getDate() {
        return date;
    }

    @Override
    public String toString() {
        return this.date.toString();
    }
    
    

}
