
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.sql.Date;
import java.util.List;


public class RoomQuery {
    
    private PreparedStatement addRoom;
    private PreparedStatement dropRoom;
    private PreparedStatement selectAllRooms;
    private PreparedStatement getroom;
    private static Connection connection;
    private PreparedStatement addRes;
    private PreparedStatement getResByRoom;
    private PreparedStatement dropResByRoom;
    private PreparedStatement getroomBySeats;
    private int seats;
    private WaitListQuery wlQuery = new WaitListQuery();
    private List <RoomEntry> result = new ArrayList <RoomEntry>();
    public String resWLString;
    public String dropRoomStr;
    private DateQuery dateQuery = new DateQuery();
    private Reservations delRes;
    private ReservationsQuery resQuery;
    
    
    
    
    public RoomQuery() {
        
        connection = dbConnection.getConnection();

        resWLString = "";
        
        dropRoomStr = "";
    }
    
    
    public void addRoom(String name, int seats) {
        
        try {
            
            addRoom = connection.prepareStatement("INSERT INTO ROOMS (NAME,SEATS) VALUES(?,?)");
            addRoom.setString(1,name);
            addRoom.setInt(2,seats);
            addRoom.executeUpdate();

            
            for (Date day:dateQuery.getAllDates()) {

                for (int j = 0; j < wlQuery.getWLByTimestamp(day).size(); j++) {                    

                    if (wlQuery.getWLByTimestamp(day).get(j).getSeats() <= seats) {

                        Timestamp presentStamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
                        
                        addRes = connection.prepareStatement("INSERT INTO RESERVATIONS (FACULTY, ROOM, DATE, SEATS, TIMESTAMP) VALUES(?, ?, ?, ?, ?)");
                        addRes.setString(1, wlQuery.getWLByTimestamp(day).get(j).getFaculty());
                        addRes.setString(2, name);
                        addRes.setDate(3, day);                    
                        addRes.setInt(4, wlQuery.getWLByTimestamp(day).get(j).getSeats());
                        addRes.setTimestamp(5, presentStamp);
                        addRes.executeUpdate();

                        resWLString += String.format("%s has reserved Room %s on: %s" + System.lineSeparator(), 
                                wlQuery.getWLByTimestamp(day).get(j).getFaculty(),name,day.toString());
                        
                        wlQuery.deletWaitlist(wlQuery.getWLByTimestamp(day).get(j).getFaculty(), day);
                    }
                    else {
                        resWLString += "Room " + name + " has been added.";
                    }
            
                }
            }  
        }
        
        catch (SQLException exception) {
            exception.printStackTrace();
        }

    }
       
    
    
    
    public void dropRoom( String name) {
        
        
        List <Reservations> result = new ArrayList <Reservations>();
        
        result = null;
        
        ResultSet resultSet = null;
        
        ArrayList <String> reservedroom = new ArrayList <String>();
        
        try {
            
            dropRoomStr = "";
            
            Timestamp presentStamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
            
            dropRoom = connection.prepareStatement("DELETE FROM ROOMS WHERE NAME = ?");
            dropRoom.setString(1, name);
            dropRoom.executeUpdate();   
            
            getResByRoom = connection.prepareStatement("SELECT * FROM RESERVATIONS WHERE ROOM = ?");
            getResByRoom.setString(1, name);
            resultSet = getResByRoom.executeQuery();
            
            ArrayList <Reservations> deletedRes = new ArrayList <Reservations>();
            
            while (resultSet.next()) {
                deletedRes.add(new Reservations(resultSet.getString("FACULTY"), resultSet.getString("ROOM"),
                    resultSet.getDate("DATE"), resultSet.getInt("SEATS"), resultSet.getTimestamp("TIMESTAMP")));
            }
        
            dropResByRoom = connection.prepareStatement("DELETE FROM RESERVATIONS WHERE ROOM = ?");
            dropResByRoom.setString(1, name);
            dropResByRoom.executeUpdate();
                        
            for (Reservations delRes: deletedRes) {
            
                wlQuery.addWaitlist(delRes.getFaculty(), delRes.getDate(), delRes.getSeats(), presentStamp);
                
                dropRoomStr += String.format("%s" + "'s reservation on %s is not possible and is waitlisted "
                        + "until a room becomes available." + System.lineSeparator(), delRes.getFaculty(), delRes.getDate().toString());
   
            }
            
//            
//            for (Reservations delRes: deletedRes) {
//
//                RoomEntry checkPossibleRes;
//                
//                checkPossibleRes = resQuery.findCorrectRoom(delRes.getSeats());
//                
//                System.out.println("aa" + checkPossibleRes.getName());
//
//                if (checkPossibleRes != null) {
//
//                    reservedroom = resQuery.getRoomsReservedByDate(delRes.getDate());
//                  
//                    
//                    if (!reservedroom.contains(checkPossibleRes.getName())) {
//
//                        for (Date day:dateQuery.getAllDates()) {
//
//
//                            for (int j = 0; j < wlQuery.getWLByTimestamp(day).size(); j++) {      
//
//                                System.out.println(wlQuery.getWLByTimestamp(day));
//
//                                if (wlQuery.getWLByTimestamp(day).get(j).getSeats() <= delRes.getSeats()) {
//
//                                    Timestamp newStamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
//
//                                    addRes = connection.prepareStatement("INSERT INTO RESERVATIONS (FACULTY, ROOM, DATE, SEATS, TIMESTAMP) VALUES(?, ?, ?, ?, ?)");
//                                    addRes.setString(1, wlQuery.getWLByTimestamp(day).get(j).getFaculty());
//                                    addRes.setString(2, name);
//                                    addRes.setDate(3, day);                    
//                                    addRes.setInt(4, wlQuery.getWLByTimestamp(day).get(j).getSeats());
//                                    addRes.setTimestamp(5, newStamp);
//                                    addRes.executeUpdate();
//
//                                    resWLString += String.format("%s has reserved Room %s on: %s" + System.lineSeparator(), 
//                                            wlQuery.getWLByTimestamp(day).get(j).getFaculty(),name,day.toString());
//
//                                    wlQuery.deletWaitlist(wlQuery.getWLByTimestamp(day).get(j).getFaculty(), day);
//                                }
//                            }
//                        }
//                    }
//                }
//
//            }
        }

        
        catch(SQLException exception) {
            exception.printStackTrace();
        }	
        
    }
    
    
    
    public ArrayList <RoomEntry> getAllRooms() {
        
        ResultSet resultSet = null;
        
        ArrayList <RoomEntry> result = new ArrayList <RoomEntry>();
        
        result = null;
        
        try {
            
            getroomBySeats = connection.prepareStatement("SELECT * FROM ROOMS ORDER BY SEATS DESC");
            resultSet = getroomBySeats.executeQuery();
           
            result = new ArrayList <RoomEntry>();
            
            
            while (resultSet.next()) {
                
                result.add(new RoomEntry(resultSet.getString("NAME"), resultSet.getInt("SEATS")));
            }


        }

        catch(SQLException exception) {
            
            exception.printStackTrace();
        }

        return result;	
    }
    
    
    public ArrayList <String> getRoomNameList() {
        
        
        ResultSet resultSet = null;
        
        ArrayList <String> name = new ArrayList <String>();
        
        try {
            
            getroom = connection.prepareStatement("SELECT * FROM ROOMS ORDER BY SEATS DESC");
            resultSet = getroom.executeQuery();
           
            name = new ArrayList <String>();
            
            
            while (resultSet.next()) {
                
                name.add(new String(resultSet.getString("NAME")));
            }


        }

        catch(SQLException exception) {
            
            exception.printStackTrace();
        }

        return name;	
        
    }

}
