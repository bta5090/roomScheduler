


public class Faculty {
    
    private String faculty;

    public Faculty(String faculty) {
        this.faculty = faculty;
    }

    public void setName(String faculty) {
        this.faculty = faculty;
    }

    public String getName() {
        return faculty;
    }
    
}
