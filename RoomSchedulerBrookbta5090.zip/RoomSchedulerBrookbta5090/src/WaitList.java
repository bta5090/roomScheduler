
import java.sql.Date;
import java.sql.Timestamp;


public class WaitList {
    
    
    private int seats;
    private String faculty;
    private Timestamp timestamp;
    private Date date;
    
    
    
    public WaitList(String faculty, Date date, int seats, Timestamp timestamp) {
        
        this.date = date;
        this.faculty = faculty;
        this.timestamp = timestamp;
        this.seats = seats;
    
    }
    
    
    public void setDate(Date date) {
        this.date = date;
    }
    
    
    public Date getDate() {
        return date;
    }
    
    
    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }
    
    
    public String getFaculty() {
        return faculty;
    }
    
 
    
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
    
    
    public Timestamp getTimestamp() {
        return timestamp;
    }

    
    public void setSeats(int seats) {
        this.seats = seats;
    }
    
    
    public int getSeats() {
        return seats;
    }

    @Override
    public String toString() {
        return this.faculty + " " + this.date + " " + this.getSeats() + " " + this.getTimestamp();
    }
    
    
    
}
